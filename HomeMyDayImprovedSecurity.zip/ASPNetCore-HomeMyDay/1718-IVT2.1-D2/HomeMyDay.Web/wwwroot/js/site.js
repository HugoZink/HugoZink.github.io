﻿$(":submit").click(function () {
    $(this).prepend('<i class="fa fa-spinner fa-spin"></i> ')
});