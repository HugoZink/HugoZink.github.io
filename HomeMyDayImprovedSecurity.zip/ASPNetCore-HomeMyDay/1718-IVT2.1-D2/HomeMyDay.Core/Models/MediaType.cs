﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeMyDay.Core.Models
{
	public enum MediaType
	{
		Unknown = 0,
		Image = 1,
		Video = 2
	}
}
