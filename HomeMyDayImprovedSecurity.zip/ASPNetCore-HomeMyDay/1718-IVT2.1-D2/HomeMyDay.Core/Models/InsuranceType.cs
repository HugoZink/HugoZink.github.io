﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeMyDay.Core.Models
{
    public enum InsuranceType
    {
		None = 0,
		Basic,
		Comfort,
		Optimal
    }
}
