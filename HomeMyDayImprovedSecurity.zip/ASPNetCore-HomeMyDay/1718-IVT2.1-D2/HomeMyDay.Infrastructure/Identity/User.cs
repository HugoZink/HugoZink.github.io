﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace HomeMyDay.Infrastructure.Identity
{
    public class User : IdentityUser
    {

    }
}
