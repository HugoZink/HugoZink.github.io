﻿using Microsoft.AspNetCore.Mvc;

namespace HomeMyDay.Web.Site.Home.Controllers
{
	public class PressController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }
    }
}
