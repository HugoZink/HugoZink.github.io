﻿using Microsoft.AspNetCore.Mvc;

namespace HomeMyDay.Web.Site.Home.Controllers
{
    class RentController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }
    }
}
