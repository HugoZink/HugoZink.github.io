﻿namespace HomeMyDay.Web.Base.Extensions
{
	public class RedirectExtension
	{
		public string SpaIp { get; set; }
		public string NodeIp { get; set; }
	}
}	 