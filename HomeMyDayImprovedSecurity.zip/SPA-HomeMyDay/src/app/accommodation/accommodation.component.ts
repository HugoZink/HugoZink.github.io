import { Component } from '@angular/core';

@Component({
  selector: 'app-accommodation',
  templateUrl: 'accommodation.component.html'
})
export class AccommodationComponent {

}
