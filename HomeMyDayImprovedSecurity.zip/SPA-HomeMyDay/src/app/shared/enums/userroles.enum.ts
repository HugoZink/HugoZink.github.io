export enum UserRoles {
    User = 'User',
    Administrator = 'Administrator'
}
